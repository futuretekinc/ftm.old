iwpriv wlan0 amsdu 2
iwpriv wlan0 ampdu 64
iwpriv wlan0 chwidth 3
iwpriv wlan0 nss 3
iwpriv wlan0 vhtmcs 9
