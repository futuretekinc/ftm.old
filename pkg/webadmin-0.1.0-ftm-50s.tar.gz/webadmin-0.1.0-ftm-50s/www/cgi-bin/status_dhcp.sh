#!/bin/ash
ps | awk 'BEGIN{count=0}{if ($4 ~/udhcpd/) { count++ }}END{ print "STATUS:", (count != 0)?"running":"stopped";}'
awk -f status_dhcp.awk /etc/config/udhcpd.conf

