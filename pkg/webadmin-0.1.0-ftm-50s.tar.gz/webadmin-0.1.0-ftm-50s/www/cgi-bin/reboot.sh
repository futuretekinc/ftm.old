#!/bin/sh

sleep 5 
sync
reboot
