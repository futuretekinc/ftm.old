#!/bin/sh

echo 0 > /proc/driver/cs752x/ne/ni/ni_fastbridge

