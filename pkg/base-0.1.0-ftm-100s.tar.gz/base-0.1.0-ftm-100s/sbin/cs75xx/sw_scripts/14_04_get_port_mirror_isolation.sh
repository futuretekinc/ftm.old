#!/bin/sh
sw_cfg -c RTK_MIRROR_PORT_ISO_GET -s
sw_cfg -c RTK_MIRROR_PORT_ISO_GET -e

