#!/bin/sh
sw_cfg -c RTK_MIRROR_PORT_ISO_SET -s
sw_cfg -c RTK_MIRROR_PORT_ISO_SET -f enable -v 1
sw_cfg -c RTK_MIRROR_PORT_ISO_SET -e

