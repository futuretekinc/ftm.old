#!/bin/sh
sw_cfg -c RTK_ACL_CFG_DELALL -s
sw_cfg -c RTK_ACL_CFG_DELALL -e

